import os

import sys
sys.path.append('waveglow/')

from itertools import cycle
import numpy as np
import scipy as sp
from scipy.io.wavfile import write
import pandas as pd
import librosa
import torch

from hparams import create_hparams
from hparams_taco2 import create_hparams as T2_create_hparams
from model import Tacotron2, load_model
from tacotron2 import Tacotron2 as T2_Tacotron2
from tacotron2 import load_model as T2_loadmodel
import modules
from waveglow.denoiser import Denoiser
from layers import TacotronSTFT
from data_utils import TextMelLoader, TextMelCollate
from text import cmudict, text_to_sequence
from text_taco2 import text_to_sequence as T2_text_to_sequence
from mellotron_utils import get_data_from_musicxml
from scipy.io.wavfile import read
from resemblyzer import VoiceEncoder, preprocess_wav
import train
from scipy.io.wavfile import read as spwavread, write as spwavwrite
import modules
import random
import torch.nn.functional as F
import shutil
import argparse
import json
from sklearn.metrics import roc_curve, auc

dummy_sid = None
datacollate = None
hparams = None
arpabet_dict = None
denoiser = None
calculate_real_EER = False

def get_cloning_and_testing_data(speaker_list, dataloader, n_cloning = 100, n_test = 100):
    testing_data = {_sid : [] for _sid in speaker_list}
    for idx in range(len(dataloader)):
        _audio_path, _text, _sid = dataloader.audiopaths_and_text[idx]
        _sid = int(_sid)
        
        if _sid in speaker_list and len(testing_data[_sid]) < n_cloning + n_test:
            testing_data[_sid].append((_audio_path, _text, _sid))
            if all(len(testing_data[key]) == (n_cloning + n_test) for key in testing_data):
                break
                
    cloning_data = {}
    val_data = {}
    
    for key in testing_data:
        cloning_data[key] = (testing_data[key][:n_cloning])
        val_data[key] = (testing_data[key][n_cloning:])
    
    return cloning_data, val_data


def _get_speaker_wise_data(file_list):
    with open(file_list) as f:
        raw_data_rows = f.read().split("\n")

    speaker_wise_data = {}
    for row in raw_data_rows:
        _fp, _text, _sid = row.split("|")
        if _sid not in speaker_wise_data:
            speaker_wise_data[_sid] = [(_fp, _text, _sid)]
        else:
            speaker_wise_data[_sid].append((_fp, _text, _sid))
    return speaker_wise_data



def _get_test_data(speaker_wise_data, speaker_key, n_examples = 10):
    rows = speaker_wise_data[speaker_key]
    test_data = rows[:n_examples]
    return test_data

def get_reference_speaker_encodings(ref_speaker_audio_paths, dataloader, resemblyzer_encoder, plotting = False):
    
    _all_wavs_resymbler = []
    pitch_mean = 0.0
    pitch_std = 0.0
    
    mel_longest = None
    longest_length = 0
    for ref_speaker_audio_path in ref_speaker_audio_paths:
        ref_mel, ref_pitch_contour = dataloader.get_mel_and_f0(ref_speaker_audio_path)
        ref_mel = ref_mel[None].cuda()
        ref_pitch_contour = ref_pitch_contour[None].cuda()
        
        wav_resembler = preprocess_wav(ref_speaker_audio_path)
        _all_wavs_resymbler.append(wav_resembler)
        if len(wav_resembler) > longest_length:
            longest_length = len(wav_resembler)
            mel_longest = ref_mel
        

        ref_pitch_contour_np = ref_pitch_contour.data.cpu().numpy().flatten()
        ref_pitch_mean = (ref_pitch_contour_np[ref_pitch_contour_np > 0]).mean()
        ref_pitch_std = (ref_pitch_contour_np[ref_pitch_contour_np > 0]).std()
        

        pitch_mean += ref_pitch_mean
        pitch_std += ref_pitch_std

    ref_speaker_embedding = resemblyzer_encoder.embed_speaker_weighted(_all_wavs_resymbler, rate=2)
    ref_speaker_embedding = torch.from_numpy(ref_speaker_embedding[None,:]).cuda()
    pitch_mean /= len(ref_speaker_audio_paths)
    pitch_std /= len(ref_speaker_audio_paths)
    
    return ref_speaker_embedding, mel_longest, pitch_mean, pitch_std

def synthesize_from_taco2(text, taco2_model, waveglow_model):
    sequence = np.array(T2_text_to_sequence(text, ['english_cleaners']))[None, :]
    sequence = torch.autograd.Variable(
        torch.from_numpy(sequence)).cuda().long()
    mel_outputs, mel_outputs_postnet, _, alignments = taco2_model.inference(sequence)
    with torch.no_grad():
        audio = waveglow_model.infer(mel_outputs_postnet, sigma=0.666)
    
    wav = audio[0].data.cpu().numpy()
    wav *= 32768.
    wav = np.clip(wav, -32768., 32767.)
    wav = wav.astype(np.int16)
    
    return wav, alignments

def scale_pitch_contour(style_pitch_contour, ref_pitch_mean, ref_pitch_std, adjust = True, scale_only_mean = True):
    style_pitch_contour_np = style_pitch_contour.flatten()
    style_pitch_mean = style_pitch_contour_np[style_pitch_contour_np > 0].mean()
    style_pitch_std = style_pitch_contour_np[style_pitch_contour_np > 0].std()
    
    if not adjust:
        ref_pitch_mean, ref_pitch_std = style_pitch_mean, style_pitch_std
    
    _indices = style_pitch_contour_np > 0
    adapted_pitch_contour_np = np.zeros(style_pitch_contour_np.shape)
    

    if adjust and scale_only_mean:
        print("Scaling pitch contour by only mean")
        adapted_pitch_contour_np[_indices] = (ref_pitch_mean/style_pitch_mean) * style_pitch_contour_np[_indices]
    else:
        adapted_pitch_contour_np[_indices] = ref_pitch_mean +  (style_pitch_contour_np[_indices] - style_pitch_mean)*(ref_pitch_std/style_pitch_std)

    adapted_pitch_mean = adapted_pitch_contour_np[adapted_pitch_contour_np > 0].mean()
    adapted_pitch_std = adapted_pitch_contour_np[adapted_pitch_contour_np > 0].std()
    adapted_pitch_contour = torch.FloatTensor(adapted_pitch_contour_np[None,None].astype(np.float32)).cuda()
    
    return adapted_pitch_contour
    
def get_conditioning_info(text, wav_path, ref_pitch_mean, ref_pitch_std, 
                          dataloader, mellotron_model, plotting = False, 
                          adjust = True, scale_only_mean = True):
    global dummy_sid
    global datacollate

    _input = dataloader.get_data([wav_path, text, dummy_sid])
    _, style_mel, _, style_pitch_contour, _ = _input
    
    adapted_pitch_contour = scale_pitch_contour(style_pitch_contour, ref_pitch_mean, ref_pitch_std, 
        adjust = adjust, scale_only_mean = scale_only_mean)
    
    x, y = mellotron_model.parse_batch(datacollate( [_input]  ))
    
    with torch.no_grad():
        _, _, _, style_rhythm = mellotron_model.forward(x)
        style_rhythm = style_rhythm.permute(1, 0, 2)
    
    
    return adapted_pitch_contour, style_rhythm


def clone_from_text_style_speaker(text, style_audio_path, ref_pitch_mean, ref_pitch_std, 
                                  ref_speaker_embedding, ref_mel,
                                 mellotron_model, fintuned_model, waveglow_model, 
                                 dataloader, adjust_pitch = True, scale_only_mean = True, denoiser_factor = 0.05):
    

    global hparams
    global arpabet_dict
    global denoiser

    pitch, rhythm = get_conditioning_info(text, style_audio_path, ref_pitch_mean, ref_pitch_std,
                                          dataloader, mellotron_model,
                                          adjust = adjust_pitch, scale_only_mean = scale_only_mean)
    text_encoded = torch.LongTensor(text_to_sequence(text, hparams.text_cleaners, arpabet_dict))[None, :].cuda()
    
    with torch.no_grad():
        mel_outputs, mel_outputs_postnet, gate_outputs, _ = fintuned_model.inference_noattention_speaker_encoder(
            (text_encoded, ref_mel, ref_speaker_embedding, pitch, rhythm))
    
    with torch.no_grad():
        audio = denoiser(waveglow_model.infer(mel_outputs_postnet, sigma=0.8), denoiser_factor)[:, 0]
    
    return audio
    
    
def clone_from_text(text, ref_pitch_mean, ref_pitch_std, ref_speaker_embedding, ref_mel,
                    taco2_model, mellotron_model, fintuned_model, waveglow_model, dataloader, 
                    scale_only_mean = True, denoiser_factor = 0.05
                    ):

    global hparams
    global arpabet_dict
    global denoiser

    wav_taco2, taco_alignment = synthesize_from_taco2(text, taco2_model, waveglow_model)
    _signature = str(int(random.random() * 100000))
    _temp_fn = "temp_{}.wav".format(_signature)
    spwavwrite(_temp_fn, 22050, wav_taco2)
    pitch, rhythm = get_conditioning_info(text, _temp_fn, ref_pitch_mean, ref_pitch_std, 
                                          dataloader, mellotron_model, scale_only_mean = scale_only_mean)
    os.remove(_temp_fn)
    
    text_encoded = torch.LongTensor(text_to_sequence(text, hparams.text_cleaners, arpabet_dict))[None, :].cuda()
    
    with torch.no_grad():
        mel_outputs, mel_outputs_postnet, gate_outputs, _ = fintuned_model.inference_noattention_speaker_encoder(
            (text_encoded, ref_mel, ref_speaker_embedding, pitch, rhythm))

    with torch.no_grad():
        audio_rhythm = denoiser(waveglow_model.infer(mel_outputs_postnet, sigma=0.8), denoiser_factor)[:, 0]
    
    with torch.no_grad():
        mel_outputs, mel_outputs_postnet, gate_outputs, aligments_melotron = fintuned_model.inference_speaker_encoder(
            (text_encoded, ref_mel, ref_speaker_embedding, pitch))
    
    #print("ALIGNMENTS MELOTRON")
    #plot_alignment_melo(aligments_melotron.data.cpu()[0,:,:].T)
    with torch.no_grad():
        audio_no_rhythm = denoiser(waveglow_model.infer(mel_outputs_postnet, sigma=0.8), denoiser_factor)[:, 0]
        
    return audio_rhythm, wav_taco2, audio_no_rhythm

def create_hparams_cloning(train_files, val_files, batch_size):
    hparams_cloning = create_hparams()
    hparams_cloning.training_files = train_files
    hparams_cloning.validation_files = val_files
    hparams_cloning.batch_size = batch_size
    hparams_cloning.learning_rate = 0.0001
    hparams_cloning.ignore_layers = []
    hparams_cloning.iters_per_checkpoint = 20
    hparams_cloning.global_spk_emb = True
    return hparams_cloning

def calculate_EER(enrollment_embeddings, candidate_embeddings):
    """
    enrollment_embeddings : dict (sp_label: emb)
    candidate_embeddings : list( (emb, sp_label) )
    For each speaker, gets same number of same-speaker and
    impostor speaker embeddings.
    """
    def calc_cosine_similarity(v1, v2):
        sim = np.dot(v1, v2)
        sim /= (np.sqrt(np.dot(v1, v1)) * np.sqrt(np.dot(v2, v2)))
        return sim


    same_speaker_embeddings = {}
    impostor_embeddings = {}
    for key in enrollment_embeddings:
        same_speaker_embeddings[key] = []
        impostor_embeddings[key] = []
        for row in candidate_embeddings:
            if row[1] == key:
                same_speaker_embeddings[key].append(row[0])
            else:
                impostor_embeddings[key].append(row[0])


    y_score = []
    y_true = []
    for key in enrollment_embeddings:
        enr_emb = enrollment_embeddings[key]
        for emb_idx in range(len(same_speaker_embeddings[key])):
            cand_emb_same = same_speaker_embeddings[key][emb_idx]
            cand_emb_impostor = impostor_embeddings[key][emb_idx]

            sim_same = calc_cosine_similarity(enr_emb, cand_emb_same)
            sim_impostor = calc_cosine_similarity(enr_emb, cand_emb_impostor)
            
            #print("Sim Same", sim_same)
            #print("Sim Impostor", sim_impostor)

            y_score += [sim_same, sim_impostor]
            y_true += [1, 0]
            
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    fnr = 1 - tpr
    eer_threshold = thresholds[np.nanargmin(np.absolute((fnr - fpr)))]
    eer = fpr[np.nanargmin(np.absolute((fnr - fpr)))]
    eer_verify = fnr[np.nanargmin(np.absolute((fnr - fpr)))]

    assert abs(eer - eer_verify) < 1.0

    return eer



def main():
    global dummy_sid
    global datacollate
    global hparams
    global arpabet_dict
    global denoiser
    global calculate_real_EER

    parser = argparse.ArgumentParser()
    parser.add_argument('-m', '--mellotron_path', type=str,
                        default="/data2/paarth/AudioTron/PreTrained/LibriAll_Synth_210000.pt",
                        help='Mellotron Path')
    parser.add_argument('-t', '--taco2_path', type=str,
                        default="/data2/paarth/AudioTron/PreTrained/tacotron2_statedict.pt",
                        help='Tacotron2 Path')
    parser.add_argument('-w', '--waveglow_path', type=str,
                        default="/data2/paarth/AudioTron/PreTrained/waveglow_256channels_v4.pt",
                        help='Wave Glow Path')
    parser.add_argument('-c', '--classifier_path', type=str,
                        default="/data2/paarth/AudioTron2/CKPTS/VCTK_ClassifierFixed/checkpoint_38000",
                        help='Speaker Classifier Path')
    parser.add_argument('-f', '--eval_filelist', type=str,
                        default="filelists/vctk_train_deepyeti.txt",
                        help='Evaluation Filelist')
    parser.add_argument('--temp_cloning_ckpt_dir', type=str,
                        default="/data2/paarth/AudioTron2/CKPTS/cloning_temp",
                        help='temp_cloning_dir')
    parser.add_argument('--temp_cloning_logs_dir', type=str,
                        default="/data2/paarth/AudioTron2/LOGS/cloning_temp",
                        help='temp_logs_dir')
    parser.add_argument('--eval_base', type=str,
                        default="/data2/paarth/AudioTron2/EVALS_115500/",
                        help='Eval Directory')
    parser.add_argument('--n_speakers', type=int,
                        default = 10,
                        help='n_speakers')
    parser.add_argument('--retraining_iters', type=int,
                        default = 100,
                        help='retraining_iters')
    parser.add_argument('-nc', '--num_cloning_samples', type=int,
                        default = 10,
                        help='num cloning samples')
    parser.add_argument('-nt', '--num_test_samples', type=int,
                        default = 5,
                        help='Num Test Samples')
    parser.add_argument('--save_wavs', type=int,
                        default = 1,
                        help='Num Test Samples')
    parser.add_argument('-rs', '--random_seed', type=int,
                        default = 30,
                        help='Random Seed')
    parser.add_argument('--cloning_source', type=str,
                        default = "style_cloning", choices = ["text_taco2_rhythm", "text_mellotron_rhythm", "style_cloning", "style_transfer"],
                        help='Num Test Samples')
    parser.add_argument('--cloning_type', type=str,
                        default = "zeroshot", choices = ["zeroshot","adaption_whole","adaption_decoder"],
                        help='Cloning Type')


    run_signature = str(int(random.random() * 100000))

    args = parser.parse_args()
    
    hparams = create_hparams()
    hparams_taco2 = T2_create_hparams()
    
    mellotron = load_model(hparams).cuda().eval()
    mellotron.load_state_dict(torch.load(args.mellotron_path)['state_dict'])
    print("Loaded Mellotron")

    taco2 = T2_loadmodel(hparams_taco2).cuda().eval()
    taco2.load_state_dict(torch.load(args.taco2_path)['state_dict'])
    print("Loaded Taco2")

    waveglow = torch.load(args.waveglow_path)['model'].cuda().eval()
    denoiser = Denoiser(waveglow).cuda().eval()
    print("Loaded waveglow")

    speaker_classifer = modules.SpeakerClassifer(hparams).cuda().eval()
    speaker_classifer.load_state_dict(torch.load(args.classifier_path)['state_dict'])
    print("Loaded Speaker Classifier")
    # speaker encoder
    resemblyzer_encoder = VoiceEncoder("cuda")
    print("Loaded Resemblyzer")

    arpabet_dict = cmudict.CMUDict('data/cmu_dictionary')
    dataloader = TextMelLoader(args.eval_filelist, hparams)
    datacollate = TextMelCollate(1)
    speaker_ids = dataloader.speaker_ids

    test_speakers = [key for key in speaker_ids]

    random.seed(args.random_seed)
    random.shuffle(test_speakers)
    test_speakers = test_speakers[:args.n_speakers]
    cloning_data, test_data = get_cloning_and_testing_data(test_speakers, dataloader)



    if args.cloning_source == "style_transfer":
        print("Updating data for style transfer")
        speaker_wise_data = _get_speaker_wise_data("filelists/blizzard_train_deepyeti.txt")
        spk_key = list(speaker_wise_data.keys())[0]
        _test_data = _get_test_data(speaker_wise_data, spk_key, n_examples = args.num_test_samples)
        for key in cloning_data:
            test_data[key] = _test_data
    elif "text" in args.cloning_source:
        # Perform cloning on the same text samples for all speakers.
        print("Updating test data to have same text for all speakers")
        speaker_wise_data = _get_speaker_wise_data(args.eval_filelist)
        all_text = [ row[1] for key in  speaker_wise_data for row in speaker_wise_data[key] ]
        random.seed(args.random_seed)
        random.shuffle(all_text)
        for key in cloning_data:
            test_rows = test_data[key]
            test_rows_updated = [ (r[0], all_text[_ridx], r[2]) for _ridx, r in enumerate(test_rows) ]
            test_data[key] = test_rows_updated

    eval_fn = args.eval_filelist.split("/")[-1][:-4]
    exp_name = "{}_{}_{}_numCloning_{}_numSpk_{}_numTest_{}_seed_{}".format(eval_fn, 
        args.cloning_source, 
        args.cloning_type, 
        args.num_cloning_samples, 
        args.n_speakers, 
        args.num_test_samples,
        args.random_seed
    )

    exp_dir = os.path.join(args.eval_base, exp_name)
    if not os.path.exists(exp_dir):
        os.makedirs(exp_dir)
    
    wav_dir = os.path.join(exp_dir, "wavs")
    if not os.path.exists(wav_dir):
        os.makedirs(wav_dir)

    dummy_sid = str(list(cloning_data.keys())[0])

    original_correct_count = 0.0
    cloned_correct_count = 0.0
    cloned_correct_top5 = 0.0
    total_count = 0.0

    num_cloning_samples = args.num_cloning_samples
    num_test_samples = args.num_test_samples
    num_enrollment_rows = 5


    for key in cloning_data:
        assert len(cloning_data[key]) >= num_cloning_samples + num_enrollment_rows
        assert len(test_data[key]) >= num_test_samples

    speaker_number = 0

    text_only_cloning = True

    retraining_iters = args.retraining_iters + 1
    fintuned_ckpt_iter = args.retraining_iters


    enrollment_embeddings = {}
    cloned_embeddings = []


    speaker_info = {}
    enrollment_embeddings = {}
    for key in cloning_data:
        print("Creating enrollment embedding", key)
        si = num_cloning_samples
        ei = num_cloning_samples + num_enrollment_rows
        enrollment_rows = cloning_data[key][si:ei]
        enrollment_paths = [row[0] for row in enrollment_rows]
        enrollment_speaker_embedding, _, _, _ = get_reference_speaker_encodings(enrollment_paths, dataloader, resemblyzer_encoder)
        enrollment_speaker_embedding = enrollment_speaker_embedding.data.cpu().numpy().flatten()
        enrollment_embeddings[key] = enrollment_speaker_embedding 

    eer_data = None
    if calculate_real_EER:
        candidate_data_actual = []
        for key in test_data:
            print("Creating candidate embedding", key)
            test_rows = test_data[key][:num_test_samples]
            
            for row in test_rows:
                _speaker_embedding, _, _, _ = get_reference_speaker_encodings([row[0]], dataloader, resemblyzer_encoder)
                _speaker_embedding = _speaker_embedding.cpu().numpy().flatten()
                candidate_data_actual.append((_speaker_embedding, key))

        eer_data = calculate_EER(enrollment_embeddings, candidate_data_actual)
        print("EER real", eer_data)

    for key in cloning_data:
        speaker_number += 1
        ref_speaker_embedding = 0
        ref_pitch_mean = 0.0
        ref_pitch_std = 0.0
        cloning_rows = cloning_data[key][:num_cloning_samples]
        test_rows = test_data[key][:num_test_samples]
        

        cloning_paths = [row[0] for row in cloning_rows]
        
        ref_speaker_embedding, ref_mel, ref_pitch_mean, ref_pitch_std = get_reference_speaker_encodings(cloning_paths, dataloader, resemblyzer_encoder)
        enrollment_speaker_embedding, _, _, _ = get_reference_speaker_encodings(enrollment_paths, dataloader, resemblyzer_encoder)

        

        print("Ref pitch mean std", ref_pitch_mean, ref_pitch_std)
        
        if "adaption" in args.cloning_type:
            """
            Retrain Mellotron
            """
            _rows = ["{}|{}|{}".format(_r[0], _r[1], _r[2]) for _r in cloning_rows]
            cloning_train_text = "\n".join(_rows)

            cloning_train_file = 'filelists/cloning_train_{}.txt'.format(run_signature)
            with open(cloning_train_file, 'w') as f:
                f.write(cloning_train_text)
            
            
            
            _val_rows = ["{}|{}|{}".format(_r[0], _r[1], _r[2]) for _r in cloning_rows[-2:]]
            cloning_val_text = "\n".join(_val_rows)

            cloning_val_file = 'filelists/cloning_val_{}.txt'.format(run_signature)
            with open(cloning_val_file, 'w') as f:
                f.write(cloning_val_text)
            
            _batch_size = 2
            if args.num_cloning_samples % 2 == 1:
                _batch_size = 1

            hparams_cloning = create_hparams_cloning(cloning_train_file, cloning_val_file, _batch_size)
            print("Starting retraining!")

            decoder_only_optimize = False
            if args.cloning_type == "adaption_decoder":
                decoder_only_optimize = True

            _ckpt_dir = os.path.join(args.temp_cloning_ckpt_dir, run_signature)
            _log_dir = os.path.join(args.temp_cloning_logs_dir, run_signature)
            train.train(_ckpt_dir, _log_dir, args.mellotron_path,
                  True, 1, 0, None, hparams_cloning, decoder_only_optimize = decoder_only_optimize, 
                  max_iter = retraining_iters)
            
            ckpt_path = os.path.join(_ckpt_dir, "checkpoint_{}".format(fintuned_ckpt_iter))
            print("Loading finetuned ckpt:", ckpt_path)
            mellotron_finetuned = load_model(hparams_cloning).cuda().eval()
            mellotron_finetuned.load_state_dict(torch.load(ckpt_path)['state_dict'])

            # delete the temporary cloning files and directory
            shutil.rmtree(_ckpt_dir)
            shutil.rmtree(_log_dir)
            os.remove(cloning_train_file)
            os.remove(cloning_val_file)

        else:
            mellotron_finetuned = mellotron
        
        for ridx, row in enumerate(test_rows):
            if args.cloning_source == "style_cloning" or args.cloning_source == "style_transfer":
                audio_cloned = clone_from_text_style_speaker(row[1], row[0], ref_pitch_mean, ref_pitch_std, 
                                          ref_speaker_embedding, ref_mel,
                                         mellotron, mellotron_finetuned, waveglow, dataloader, adjust_pitch = True)
            elif "text" in args.cloning_source:
                audio_cloned_rhythm, wav_taco2, audio_cloned_no_rhythm = clone_from_text(row[1], ref_pitch_mean, ref_pitch_std,
                                          ref_speaker_embedding, ref_mel,
                                         taco2, mellotron, mellotron_finetuned, waveglow, dataloader)
                
                if args.cloning_source == "text_taco2_rhythm":
                    audio_cloned = audio_cloned_rhythm
                elif args.cloning_source == "text_mellotron_rhythm":
                    audio_cloned = audio_cloned_no_rhythm
                else:
                    raise NotImplementedError("invalid cloning source")


            _, original_label = speaker_classifer(ref_speaker_embedding).max(1)
            original_label = original_label.item()
            true_label = speaker_ids[key]
            
            wav = audio_cloned[0].data.cpu().numpy()
            wav *= 32768.
            wav = np.clip(wav, -32768., 32767.)
            wav = wav.astype(np.int16)


            temp_clone_path = "temp_cloned_{}.wav".format(run_signature)
            spwavwrite(temp_clone_path, 22050, wav)
            wav_resembler = preprocess_wav(temp_clone_path)
            os.remove(temp_clone_path)

            cloned_embedding = resemblyzer_encoder.embed_utterance(wav_resembler, rate=2)
            cloned_embedding_tensor = torch.from_numpy(cloned_embedding[None,:]).cuda()
            cloned_embeddings.append((cloned_embedding.flatten(), key))

            scores = speaker_classifer(cloned_embedding_tensor)
            _, cloned_label = scores.max(1)
            _, cloned_top5_labels = scores[0].topk(5)
            
            cloned_label = cloned_label.item()
            print("Cloned Original True Label", cloned_label, original_label, true_label)
            print("Top 5 labels", cloned_top5_labels)
            if original_label == true_label:
                original_correct_count += 1
            if cloned_label == true_label:
                cloned_correct_count += 1
            if true_label in cloned_top5_labels:
                cloned_correct_top5 += 1
                
            total_count += 1
            

            print("SNo.:", speaker_number, "Speaker key:", key, "Audio no.:",ridx)
            print("Original acc.", original_correct_count/total_count)
            print("Cloned acc.", cloned_correct_count/total_count)
            print("Cloned Top5 acc.", cloned_correct_top5/total_count)
            print("************************")



            if args.save_wavs == 1:
                _fn = row[0].split("/")[-1][:-4]

                clone_path = os.path.join(wav_dir, "{}_cloned.wav".format(_fn))
                spwavwrite(clone_path, 22050, wav)
                test_path = os.path.join(wav_dir, "{}.wav".format(_fn))
                shutil.copyfile(row[0], test_path)
                
                speaker_path = os.path.join(wav_dir, "{}_spk.wav".format(_fn))
                shutil.copyfile(cloning_rows[0][0], speaker_path)

                transcript_path = test_path.replace(".wav", ".txt")
                with open(transcript_path, "w") as f:
                    f.write(row[1])

            stats = {
                'total_wavs' : total_count,
                'num_speakers' : args.n_speakers,
                'num_cloning_samples' : args.num_cloning_samples,
                'num_test_samples' : args.num_test_samples,
                'mellotron_path' : args.mellotron_path,
                'speaker_classifer_path' : args.classifier_path,
                'eval_filelist' : args.eval_filelist,
                'OriginalAcc' : original_correct_count/total_count,
                'ClonedAcc' : cloned_correct_count/total_count,
                'ClonedTop5Acc' : cloned_correct_top5/total_count,
                'eer_real_samples' : eer_data,
            }

            with open(os.path.join(exp_dir, "stats.json"), 'w') as f:
                f.write(json.dumps(stats))

    eer = calculate_EER(enrollment_embeddings, cloned_embeddings)
    stats['eer'] = eer

    with open(os.path.join(exp_dir, "stats.json"), 'w') as f:
        f.write(json.dumps(stats))

if __name__ == '__main__':
    main()