from flask import Flask
from flask_ngrok import run_with_ngrok
from flask_cors import CORS
app = Flask(__name__)
run_with_ngrok(app)  # Start ngrok when app is run
CORS(app)

import sys
from flask import request
import os
import librosa
import numpy as np
from scipy.io.wavfile import read as spwavread, write as spwavwrite
import VoiceClonerWebApp
import json
import torch
from base64 import b64encode

vc_options = {
    'mellotron_path' : "/data2/paarth/AudioTron/PreTrained/LibriAll_Synth_210000.pt",
    'taco2_path' : "/data2/paarth/AudioTron/PreTrained/tacotron2_statedict.pt",
    'waveglow_path' : "/data2/paarth/AudioTron/PreTrained/waveglow_256channels_v4.pt",
    'temp_cloning_ckpt_dir' : "/data2/paarth/AudioTronWebApp/CKPTS",
    'temp_cloning_logs_dir' : "/data2/paarth/AudioTronWebApp/LOGS"
}

vc = VoiceClonerWebApp.VoiceCloner(options = vc_options)


@app.route('/test_connection')
def test_connection():
    return 'works!'


@app.route('/submit_recordings', methods=['POST'])
def parse_request():
    global vc
    total_wavs = int(request.values.get('total_wavs'))
    session_key = request.values.get('session_key')

    all_data = []
    for wav_no in range(total_wavs):
        transcript = request.values.get('transcript_{}'.format(wav_no))
        audio_data = request.files['audio_data_{}'.format(wav_no)]
        all_data.append({
            'transcript' : transcript,
            'audio_data' : audio_data
            })
    
    
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    if not os.path.exists(cloning_directory):
        os.makedirs(cloning_directory)

    cloning_fn = os.path.join(cloning_directory, "cloning_file_list.txt")
    
    cloning_file_row_list = []
    for ridx, row in enumerate(all_data):
        wav, _ = librosa.load(row['audio_data'], sr = 22050)
        wav *= 32768.
        wav = np.clip(wav, -32768., 32767.)
        wav = wav.astype(np.int16)
        audio_fn = os.path.join(cloning_directory, "wav_file_{}.wav".format(ridx))
        spwavwrite(audio_fn, 22050, wav)
        row_str = "{}|{}|1".format(audio_fn, row['transcript'])
        cloning_file_row_list.append(row_str)
    
    with open(cloning_fn, "w") as f:
        f.write("\n".join(cloning_file_row_list))

    speaker_profile = vc.create_speaker_profile(cloning_fn)
    speaker_profile['ref_speaker_embedding'] = speaker_profile['ref_speaker_embedding'].data.cpu().numpy().tolist()
    speaker_profile['ref_mel'] = speaker_profile['ref_mel'].data.cpu().numpy().tolist()
    speaker_profile['ref_pitch_mean'] = float(speaker_profile['ref_pitch_mean'])
    speaker_profile['ref_pitch_std'] = float(speaker_profile['ref_pitch_std'])

    speaker_profile_fn = os.path.join(cloning_directory, "speaker_profile.json")
    with open(speaker_profile_fn, 'w') as f:
        f.write(json.dumps(speaker_profile))

    return 'Hello, World!'


@app.route('/fine_tune_model_old', methods=['GET'])
def fine_tune_model_old():
    global vc
    session_key = request.values.get('session_key')
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())
    speaker_profile['ref_speaker_embedding'] = torch.from_numpy(np.asarray(speaker_profile['ref_speaker_embedding'], dtype='float32')).cuda()
    speaker_profile['ref_mel'] = torch.from_numpy(np.asarray(speaker_profile['ref_mel'], dtype='float32')).cuda()
    
    print("SP CLONING", speaker_profile['cloning_data'])
    finetuned_ckpt_path = vc.finetune_synthesizer(speaker_profile, session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())

    speaker_profile['finetuned_model'] = finetuned_ckpt_path
    with open(os.path.join(cloning_directory, "speaker_profile.json"), 'w') as f:
        f.write(json.dumps(speaker_profile))

    vc.update_finetuned_model_cache(finetuned_ckpt_path, session_key)

    return "done"

@app.route('/fine_tune_model', methods=['GET'])
def fine_tune_model():
    global vc
    session_key = request.values.get('session_key')
    log_dir = os.path.join(vc_options['temp_cloning_logs_dir'], session_key)
    progress_file = os.path.join(log_dir, "progress.json")
    if os.path.exists(progress_file):
        os.remove(progress_file)
    
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())
    if 'finetuned_model' in speaker_profile:
        del speaker_profile['finetuned_model']
    
    with open(os.path.join(cloning_directory, "speaker_profile.json"), 'w') as f:
        f.write( json.dumps(speaker_profile) )
        
    os.system("CUDA_VISIBLE_DEVICES=2 python finetune_commandline.py --session_key {} &".format(session_key))
    
    return "started finetuning in background"


@app.route('/get_fine_tuning_status', methods=['GET'])
def get_fine_tuning_status():
    
    session_key = request.values.get('session_key')
    log_dir = os.path.join(vc_options['temp_cloning_logs_dir'], session_key)
    progress_file = os.path.join(log_dir, "progress.json")
    
    if not os.path.exists(progress_file):
        return json.dumps({
            'iters_complete' : 0,
            'training_complete': False
        })
    else:
        with open(progress_file) as f:
            progress_data = json.loads(f.read())

        return json.dumps(progress_data)

@app.route('/get_audio_from_text', methods=['GET'])
def get_audio_from_text():
    global vc
    session_key = request.values.get('session_key')
    text = request.values.get('text')
    
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())
    speaker_profile['ref_speaker_embedding'] = torch.from_numpy(np.asarray(speaker_profile['ref_speaker_embedding'], dtype='float32')).cuda()
    speaker_profile['ref_mel'] = torch.from_numpy(np.asarray(speaker_profile['ref_mel'], dtype='float32')).cuda()
    
    
    wav_zeroshot = vc.synthesize_from_text(text, speaker_profile, None)
    
    finetuned_model = None
    wav_adaption = None
    if 'finetuned_model' in speaker_profile:
        finetuned_model = vc.get_finetuned_model(speaker_profile['finetuned_model'], session_key)
        print("Loaded Finetuned Model")
        wav_adaption = vc.synthesize_from_text(text, speaker_profile, finetuned_model)
    
    

    test_fn = os.path.join(cloning_directory, "test.wav")
    spwavwrite(test_fn, 22050, wav_zeroshot)
    with open(test_fn, 'rb') as f:
        audio_base64_zeroshot = b64encode(f.read())
    
    if wav_adaption is not None:
        spwavwrite(test_fn, 22050, wav_adaption)
        with open(test_fn, 'rb') as f:
            audio_base64_adaption = b64encode(f.read())

        return json.dumps({
            'audio_base64_zeroshot' : audio_base64_zeroshot.decode('ascii'),
            'audio_base64_adaption' : audio_base64_adaption.decode('ascii')
        })
    else:
        return json.dumps({
            'audio_base64_zeroshot' : audio_base64_zeroshot.decode('ascii'),
            'audio_base64_adaption' : None
        })


@app.route('/get_style_transfer_results', methods=['GET'])
def get_style_transfer_results():
    global vc
    session_key = request.values.get('session_key')
    cloning_type = request.values.get('cloning_type')
    
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())
    speaker_profile['ref_speaker_embedding'] = torch.from_numpy(np.asarray(speaker_profile['ref_speaker_embedding'], dtype='float32')).cuda()
    speaker_profile['ref_mel'] = torch.from_numpy(np.asarray(speaker_profile['ref_mel'], dtype='float32')).cuda()
    
    finetuned_model = None
    if cloning_type == "adaption":
        if 'finetuned_model' in speaker_profile:
            finetuned_model = vc.get_finetuned_model(speaker_profile['finetuned_model'], session_key)
            print("Loaded Finetuned Model")
        else:
            raise NotImplementedError()

    cloning_list = []
    speaker_cloning_data = speaker_profile['cloning_data']
    for ridx in range(2):
        cr = speaker_cloning_data[ridx]
        cloning_list.append(("Speaker data", cr[0], cr[1] ))

    with open("filelists/style_transfer_webapp.txt") as f:
        _raw_text = f.read()

    _rows = _raw_text.split("\n")
    for _row in _rows:
        cloning_list.append(_row.split("|"))


    all_data = [] 
    for _row in cloning_list:

        wav = vc.synthesize_from_style_and_text(_row[1], _row[2], speaker_profile, finetuned_model)
        test_fn = os.path.join(cloning_directory, "test.wav")
        spwavwrite(test_fn, 22050, wav)
        with open(test_fn, 'rb') as f:
            synthesized_base64 = b64encode(f.read())
        
        with open(_row[1], 'rb') as f:
            style_base64 = b64encode(f.read())

        all_data.append({
            'synthesized_audio' : synthesized_base64.decode('ascii'),
            'style_audio' : style_base64.decode('ascii'),
            'ref_type' : _row[0]
        })

    
    return json.dumps(all_data)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=1222)
