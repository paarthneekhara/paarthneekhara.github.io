import os
import librosa
import numpy as np
from scipy.io.wavfile import read as spwavread, write as spwavwrite
import VoiceClonerWebApp
import json
import torch
from base64 import b64encode
import argparse



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--session_key', type=str, default=None,
                        required=True)
    
    args = parser.parse_args()
    
    
    vc_options = {
        'mellotron_path' : "/data2/paarth/AudioTron/PreTrained/LibriAll_Synth_210000.pt",
        'taco2_path' : "/data2/paarth/AudioTron/PreTrained/tacotron2_statedict.pt",
        'waveglow_path' : "/data2/paarth/AudioTron/PreTrained/waveglow_256channels_v4.pt",
        'temp_cloning_ckpt_dir' : "/data2/paarth/AudioTronWebApp/CKPTS",
        'temp_cloning_logs_dir' : "/data2/paarth/AudioTronWebApp/LOGS"
    }

    vc = VoiceClonerWebApp.VoiceCloner(options = vc_options)

    session_key = args.session_key
    
    cloning_directory = "data/cloning_web_app/{}".format(session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())
    speaker_profile['ref_speaker_embedding'] = torch.from_numpy(np.asarray(speaker_profile['ref_speaker_embedding'], dtype='float32')).cuda()
    speaker_profile['ref_mel'] = torch.from_numpy(np.asarray(speaker_profile['ref_mel'], dtype='float32')).cuda()
    
    print("SP CLONING", speaker_profile['cloning_data'])
    finetuned_ckpt_path = vc.finetune_synthesizer(speaker_profile, session_key)
    with open(os.path.join(cloning_directory, "speaker_profile.json")) as f:
        speaker_profile = json.loads(f.read())

    speaker_profile['finetuned_model'] = finetuned_ckpt_path
    with open(os.path.join(cloning_directory, "speaker_profile.json"), 'w') as f:
        f.write(json.dumps(speaker_profile))
    
    print("Model Finetuned and speaker profile updated")
    
if __name__ == '__main__':
    main()
