import os

import sys
sys.path.append('waveglow/')

import numpy as np
import librosa
import torch
from scipy.io.wavfile import read as spwavread, write as spwavwrite
from hparams import create_hparams
from hparams_taco2 import create_hparams as T2_create_hparams
from model import Tacotron2, load_model
from tacotron2 import Tacotron2 as T2_Tacotron2
from tacotron2 import load_model as T2_loadmodel
import modules
from waveglow.denoiser import Denoiser
from data_utils import TextMelLoader, TextMelCollate
from text import cmudict, text_to_sequence
from text_taco2 import text_to_sequence as T2_text_to_sequence
from mellotron_utils import get_data_from_musicxml
from scipy.io.wavfile import read
from resemblyzer import VoiceEncoder, preprocess_wav
import train
import random
import torch.nn.functional as F
import shutil
import argparse
import json
from sklearn.metrics import roc_curve, auc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pylab as plt

class VoiceCloner:
    def __init__(self, options):
        self.options = options
        self.hparams = create_hparams()
        self.hparams_taco2 = T2_create_hparams()
        self.mellotron_path = options['mellotron_path']
        self.taco2_path = options['taco2_path']
        self.waveglow_path = options['waveglow_path']
        self._load_checkpoints()
        self.arpabet_dict = cmudict.CMUDict('data/cmu_dictionary')
        self.dataloader = TextMelLoader("data/examples_filelist.txt", self.hparams)
        self.datacollate = TextMelCollate(1)
        _, _, self.dummy_sid = self.dataloader.audiopaths_and_text[0]
        self.finetuned_models_cache = {}
        self.max_cache_size = 2
        self.global_cache_counter = 0

    def update_finetuned_model_cache(self, ckpt_path, session_key):
        if len(self.finetuned_models_cache) < self.max_cache_size:
            self.finetuned_models_cache[session_key] = {
                'model' : self.load_mellotron_from_checkpoint(ckpt_path),
                'date_time' : self.global_cache_counter
            }
        else:
            first_key = self.finetuned_models_cache.keys()[0]
            del self.finetuned_models_cache[first_key]
            self.finetuned_models_cache[session_key] = {
                'model' : self.load_mellotron_from_checkpoint(ckpt_path),
                'date_time' : self.global_cache_counter
            }

        return None


    def get_finetuned_model(self, ckpt_path, session_key):
        if session_key in self.finetuned_models_cache:
            return self.finetuned_models_cache[session_key]['model']
        else:
            self.update_finetuned_model_cache(ckpt_path, session_key)
            return self.finetuned_models_cache[session_key]['model']

    def create_speaker_profile(self, cloning_filelist):
        with open(cloning_filelist) as f:
            raw_data_rows = f.read().split("\n")

        cloning_data = []
        for row in raw_data_rows:
            _audio_path, _text, _sid = row.split("|")
            cloning_data.append((_audio_path, _text, _sid))

        
        ref_speaker_embedding, ref_mel, ref_pitch_mean, ref_pitch_std = self._get_speaker_encodings(cloning_data)

        speaker_profile = {
            'ref_speaker_embedding' : ref_speaker_embedding,
            'ref_mel' : ref_mel,
            'ref_pitch_mean' : ref_pitch_mean,
            'ref_pitch_std' : ref_pitch_std,
            'cloning_data' : cloning_data
        }

        return speaker_profile

    def load_mellotron_from_checkpoint(self, ckpt_path):
        print("Loading Checkpoint From",  ckpt_path)
        hparams = self.hparams
        mellotron = load_model(hparams).cuda().eval()
        mellotron.load_state_dict(torch.load(ckpt_path)['state_dict'])
        return mellotron

    def _load_checkpoints(self):
        hparams = self.hparams
        hparams_taco2 = self.hparams_taco2

        mellotron = load_model(hparams).cuda().eval()
        mellotron.load_state_dict(torch.load(self.mellotron_path)['state_dict'])
        print("Loaded Mellotron")

        taco2 = T2_loadmodel(hparams_taco2).cuda().eval()
        taco2.load_state_dict(torch.load(self.taco2_path)['state_dict'])
        print("Loaded Taco2")

        waveglow = torch.load(self.waveglow_path)['model'].cuda().eval()
        denoiser = Denoiser(waveglow).cuda().eval()
        print("Loaded waveglow")

        resemblyzer_encoder = VoiceEncoder("cuda")
        print("Loaded Resemblyzer")

        self.mellotron = mellotron
        # elf.mellotron_finetuned = mellotron #will be overridden if retrained 
        self._mellotron_finetuned_backup = mellotron
        self.taco2 = taco2
        self.waveglow = waveglow
        self.denoiser = denoiser
        self.resemblyzer_encoder = resemblyzer_encoder

    def _get_speaker_encodings(self, cloning_data):
        ref_speaker_audio_paths = [row[0] for row in cloning_data]
        dataloader = self.dataloader
        resemblyzer_encoder = self.resemblyzer_encoder

        _all_wavs_resymbler = []
        pitch_mean = 0.0
        pitch_std = 0.0
        
        mel_longest = None
        longest_length = 0
        for ref_speaker_audio_path in ref_speaker_audio_paths:
            ref_mel, ref_pitch_contour = dataloader.get_mel_and_f0(ref_speaker_audio_path)
            ref_mel = ref_mel[None].cuda()
            ref_pitch_contour = ref_pitch_contour[None].cuda()
            
            wav_resembler = preprocess_wav(ref_speaker_audio_path)
            _all_wavs_resymbler.append(wav_resembler)
            if len(wav_resembler) > longest_length:
                longest_length = len(wav_resembler)
                mel_longest = ref_mel
            

            ref_pitch_contour_np = ref_pitch_contour.data.cpu().numpy().flatten()
            ref_pitch_mean = (ref_pitch_contour_np[ref_pitch_contour_np > 0]).mean()
            ref_pitch_std = (ref_pitch_contour_np[ref_pitch_contour_np > 0]).std()
            

            pitch_mean += ref_pitch_mean
            pitch_std += ref_pitch_std

        ref_speaker_embedding = resemblyzer_encoder.embed_speaker_weighted(_all_wavs_resymbler, rate=2)
        ref_speaker_embedding = torch.from_numpy(ref_speaker_embedding[None,:]).cuda()
        pitch_mean /= len(ref_speaker_audio_paths)
        pitch_std /= len(ref_speaker_audio_paths)

        return ref_speaker_embedding, mel_longest, pitch_mean, pitch_mean


    def finetune_synthesizer(self, speaker_profile, session_key, retraining_iters = 100, 
                                    adaption_type = "whole", 
                                    learning_rate = 0.0001, 
                                    n_val = 0):
        assert adaption_type in ["decoder_only", "whole"]
        assert session_key is not None

        options = self.options
        def create_hparams_cloning(train_files, val_files, batch_size, iters_per_ckpt):
            
            hparams_cloning = create_hparams()
            hparams_cloning.training_files = train_files
            hparams_cloning.validation_files = val_files
            hparams_cloning.batch_size = batch_size
            hparams_cloning.learning_rate = learning_rate
            hparams_cloning.ignore_layers = []
            hparams_cloning.iters_per_checkpoint = iters_per_ckpt
            hparams_cloning.global_spk_emb = True
            return hparams_cloning

        # print(speaker_profile['cloning_data'])
        _train_data = speaker_profile['cloning_data'][:]
        # print(_train_data)
        _rows = ["{}|{}|{}".format(_r[0], _r[1], _r[2]) for _r in _train_data]
        cloning_train_text = "\n".join(_rows)
        batch_size = len(_rows)

        train_file_txt = 'filelists/vc_cloning_{}_train.txt'.format(session_key)
        val_file_txt = 'filelists/vc_cloning_{}_val.txt'.format(session_key)

        with open(train_file_txt, 'w') as f:
            f.write(cloning_train_text)
         
        if n_val > 0:
            _val_data = speaker_profile['cloning_data'][-n_val:]
        else:
            _val_data = _train_data[-2:]

        _val_rows = ["{}|{}|{}".format(_r[0], _r[1], _r[2]) for _r in _val_data]
        cloning_val_text = "\n".join(_val_rows)
        with open(val_file_txt, 'w') as f:
            f.write(cloning_val_text)

        hparams_cloning = create_hparams_cloning(train_file_txt, val_file_txt, batch_size, retraining_iters)

        decoder_only_optimize = False
        if adaption_type == "decoder_only":
            decoder_only_optimize = True

        temp_ckpt_dir = os.path.join(options['temp_cloning_ckpt_dir'], session_key)
        temp_log_dir = os.path.join(options['temp_cloning_logs_dir'], session_key)

        train.train(temp_ckpt_dir,
                    temp_log_dir, 
                    options['mellotron_path'],
                    True, 1, 0, None, hparams_cloning,
                    decoder_only_optimize = decoder_only_optimize, 
                    max_iter = retraining_iters + 1
                    )
        
        ckpt_path = os.path.join(temp_ckpt_dir, "checkpoint_{}".format(retraining_iters))
        
        return ckpt_path
        # print("Loading finetuned ckpt:", ckpt_path)
        # mellotron_finetuned = load_model(hparams_cloning).cuda().eval()
        # mellotron_finetuned.load_state_dict(torch.load(ckpt_path)['state_dict'])
        # self.mellotron_finetuned = mellotron_finetuned
        # self._mellotron_finetuned_backup = mellotron_finetuned

    def _scale_pitch_contour(self, style_pitch_contour, ref_pitch_mean, ref_pitch_std, adjust = True, scale_only_mean = True):
        style_pitch_contour_np = style_pitch_contour.flatten()
        style_pitch_mean = style_pitch_contour_np[style_pitch_contour_np > 0].mean()
        style_pitch_std = style_pitch_contour_np[style_pitch_contour_np > 0].std()
        
        if not adjust:
            ref_pitch_mean, ref_pitch_std = style_pitch_mean, style_pitch_std
        
        _indices = style_pitch_contour_np > 0
        adapted_pitch_contour_np = np.zeros(style_pitch_contour_np.shape)

        adapted_pitch_contour_np[_indices] = ref_pitch_mean +  (style_pitch_contour_np[_indices] - style_pitch_mean)*(ref_pitch_std/style_pitch_std)
        
        if adjust and scale_only_mean:
            adapted_pitch_contour_np[_indices] = (ref_pitch_mean/style_pitch_mean) * style_pitch_contour_np[_indices]

        adapted_pitch_mean = adapted_pitch_contour_np[adapted_pitch_contour_np > 0].mean()
        adapted_pitch_std = adapted_pitch_contour_np[adapted_pitch_contour_np > 0].std()
        adapted_pitch_contour = torch.FloatTensor(adapted_pitch_contour_np[None,None].astype(np.float32)).cuda()
        
        return adapted_pitch_contour

    def _get_conditioning_info(self, text, wav_path, speaker_profile, adjust = True, scale_only_mean = True):
        
        dummy_sid = self.dummy_sid
        datacollate = self.datacollate
        dataloader = self.dataloader
        mellotron_model = self.mellotron
        ref_pitch_mean = speaker_profile['ref_pitch_mean']
        ref_pitch_std = speaker_profile['ref_pitch_std']

        _input = dataloader.get_data([wav_path, text, dummy_sid])
        _, style_mel, _, style_pitch_contour, _ = _input
        
        adapted_pitch_contour = self._scale_pitch_contour(style_pitch_contour, 
            ref_pitch_mean, ref_pitch_std, adjust = adjust, scale_only_mean = scale_only_mean)
        
        x, y = mellotron_model.parse_batch(datacollate( [_input]  ))
        
        with torch.no_grad():
            _, _, _, style_rhythm = mellotron_model.forward(x)
            style_rhythm = style_rhythm.permute(1, 0, 2)
        
        
        return adapted_pitch_contour, style_rhythm

    def get_mel_spectrogram(self, wav_path):
        """
        Returns mel spectrogram as cuda with batch dimension added.
        """
        mel, _ = self.dataloader.get_mel_and_f0(wav_path)
        return mel[None].cuda()

    def get_pitch_contour(self, wav_path):
        """
        Returns pitch contour as cuda with batch dimension added.
        """
        _, pitch_contour = self.dataloader.get_mel_and_f0(wav_path)
        return pitch_contour[None].cuda()

    def get_rhythm(self, wav_path, text):
        """
        Returns alignment as cuda with batch dimension added.
        """
        dummy_sid = self.dummy_sid
        datacollate = self.datacollate
        dataloader = self.dataloader
        mellotron_model = self.mellotron

        _input = dataloader.get_data([wav_path, text, dummy_sid])
        x, y = mellotron_model.parse_batch(datacollate( [_input]  ))

        with torch.no_grad():
            _, _, _, rhythm = mellotron_model.forward(x)
            rhythm = rhythm.permute(1, 0, 2)

        return rhythm


    def synthesize_full_control(self, text, pitch, ref_mel, ref_speaker_embedding, 
        finetuned_model = None,
        rhythm = None, denoise_factor = 0.05):
        hparams = self.hparams
        arpabet_dict = self.arpabet_dict

        text_encoded = torch.LongTensor(text_to_sequence(text, hparams.text_cleaners, arpabet_dict))[None, :].cuda()

        if finetuned_model is None:
            finetuned_model = self.mellotron

        if rhythm is not None:
            with torch.no_grad():
                mel_outputs, mel_outputs_postnet, gate_outputs, _ = finetuned_model.inference_noattention_speaker_encoder(
                    (text_encoded, ref_mel, ref_speaker_embedding, pitch, rhythm)) 
        else:
            with torch.no_grad():
                mel_outputs, mel_outputs_postnet, gate_outputs, _ = finetuned_model.inference_speaker_encoder(
                    (text_encoded, ref_mel, ref_speaker_embedding, pitch))

        with torch.no_grad():
            audio = self.denoiser(self.waveglow.infer(mel_outputs_postnet, sigma=0.8), denoise_factor)[:, 0]

        wav = audio[0].data.cpu().numpy()
        wav *= 32768.
        wav = np.clip(wav, -32768., 32767.)
        wav = wav.astype(np.int16)

        return wav


    def synthesize_from_style_and_text(self, style_audio_path, text, speaker_profile, finetuned_model = None,
        adjust_pitch = True, scale_only_mean = True, gst_token = None, denoise_factor = 0.05):
        
        hparams = self.hparams
        arpabet_dict = self.arpabet_dict

        text_encoded = torch.LongTensor(text_to_sequence(text, hparams.text_cleaners, arpabet_dict))[None, :].cuda()
        pitch, rhythm = self._get_conditioning_info(text, style_audio_path, speaker_profile, adjust = adjust_pitch, scale_only_mean = scale_only_mean)
        ref_mel = speaker_profile['ref_mel']
        if gst_token is not None:
            ref_mel = gst_token
        ref_speaker_embedding = speaker_profile['ref_speaker_embedding']
        if finetuned_model is None:
            finetuned_model = self.mellotron
        with torch.no_grad():
            mel_outputs, mel_outputs_postnet, gate_outputs, _ = finetuned_model.inference_noattention_speaker_encoder(
                (text_encoded, ref_mel, ref_speaker_embedding, pitch, rhythm))
    
        with torch.no_grad():
            audio = self.denoiser(self.waveglow.infer(mel_outputs_postnet, sigma=0.8), denoise_factor)[:, 0]
        
        wav = audio[0].data.cpu().numpy()
        wav *= 32768.
        wav = np.clip(wav, -32768., 32767.)
        wav = wav.astype(np.int16)

        return wav

    def _synthesize_from_taco2(self, text):
        sequence = np.array(T2_text_to_sequence(text, ['english_cleaners']))[None, :]
        sequence = torch.autograd.Variable(
            torch.from_numpy(sequence)).cuda().long()
        
        mel_outputs, mel_outputs_postnet, _, alignments = self.taco2.inference(sequence)
        with torch.no_grad():
            audio = self.waveglow.infer(mel_outputs_postnet, sigma=0.666)
        
        wav = audio[0].data.cpu().numpy()
        wav *= 32768.
        wav = np.clip(wav, -32768., 32767.)
        wav = wav.astype(np.int16)
        
        return wav, alignments

    def synthesize_from_text(self, text, speaker_profile, finetuned_model = None,
        rhythm_source="taco2", scale_only_mean = True, 
        gst_token = None, denoise_factor = 0.05):
        hparams = self.hparams
        arpabet_dict = self.arpabet_dict

        wav_taco2, taco_alignment = self._synthesize_from_taco2(text)
        spwavwrite("temp.wav", 22050, wav_taco2)
        pitch, rhythm = self._get_conditioning_info(text, "temp.wav", speaker_profile, adjust = True, scale_only_mean = scale_only_mean)
        text_encoded = torch.LongTensor(text_to_sequence(text, hparams.text_cleaners, arpabet_dict))[None, :].cuda()

        ref_mel = speaker_profile['ref_mel']
        ref_speaker_embedding = speaker_profile['ref_speaker_embedding']

        if finetuned_model is None:
            finetuned_model = self.mellotron

        if gst_token is not None:
            ref_mel = gst_token

        with torch.no_grad():
            if rhythm_source == "taco2":
                mel_outputs, mel_outputs_postnet, gate_outputs, _ = finetuned_model.inference_noattention_speaker_encoder(
                    (text_encoded, ref_mel, ref_speaker_embedding, pitch, rhythm))
            else:
                mel_outputs, mel_outputs_postnet, gate_outputs, aligments_melotron = finetuned_model.inference_speaker_encoder(
                    (text_encoded, ref_mel, ref_speaker_embedding, pitch))

        with torch.no_grad():
            audio = self.denoiser(self.waveglow.infer(mel_outputs_postnet, sigma=0.8), denoise_factor)[:, 0]

        wav = audio[0].data.cpu().numpy()
        wav *= 32768.
        wav = np.clip(wav, -32768., 32767.)
        wav = wav.astype(np.int16)

        return wav

    def save_figure_to_numpy(self, fig):
        # save it to a numpy array.
        data = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
        data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        return data

    def plot_mel_spectrogram(self, mel, figsize = (6, 4)):
        spectrogram = mel[0].data.cpu().numpy()
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(spectrogram, aspect="auto", origin="lower",
                       interpolation='none')
        plt.colorbar(im, ax=ax)
        plt.xlabel("Frames")
        plt.ylabel("Channels")
        plt.tight_layout()

        fig.canvas.draw()
        data = self.save_figure_to_numpy(fig)
        plt.close()
        return data

    def plot_rhythm(self, rhythm, figsize=(6, 4)):
        alignment = rhythm[0].data.cpu().numpy().T
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(alignment, aspect='auto', origin='lower',
                   interpolation='none')
        fig.colorbar(im, ax=ax)
        xlabel = 'Decoder timestep'
        
        plt.xlabel(xlabel)
        plt.ylabel('Encoder timestep')
        plt.tight_layout()

        fig.canvas.draw()
        data = self.save_figure_to_numpy(fig)
        plt.close()
        return data

    def plot_pitch_contour(self, pitch_contour, figsize=(6, 4)):
        pitch = pitch_contour[0].data.cpu().numpy().flatten()
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.plot(range(len(pitch)), pitch)
        plt.xlabel("Frames")
        plt.ylabel("F0")

        fig.canvas.draw()
        data = self.save_figure_to_numpy(fig)
        plt.close()


        return data
